import processing.core.*; 
import processing.xml.*; 

import processing.pdf.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Final380DataJunker extends PApplet {

//~*^~*^~*^~*^~*^~*^~*^~*^~*^~*^
//Datajunker by Patrick C Clarke
//~*^~*^~*^~*^~*^~*^~*^~*^~*^~*^

//Major Variables



ArrayList lump1, lump2;

PImage bar1, bar2;

BarChart myBar;
PieChart myPie1, myPie2;
ThreeDeeLineGraph my3dLineGraph, my3dLineGraph2;

PGraphicsPDF pdf;

String header1, headerPie, header3d;
int slide;

/*******************************
~~~~~~~~~SETUP FUNCTION~~~~~~~~~
*******************************/
public void setup() 
{
  size(1024, 768/*, PDF, "screen3.pdf"*/);
  smooth();
  
  slide = 0;
  
  lump1 = new ArrayList();
  lump2 = new ArrayList();
  
  /**************
  BAR CHART
  ***************/
  for(int i = 0; i < 9; i++)
  {
    lump1.add(PApplet.parseInt(XMLGetString("news/news_entry/num_related", "data", "http://www.google.com/ig/api?news")));
    lump2.add(XMLGetString("news/news_entry/num_related", "data", "http://www.google.com/ig/api?news"));
  }
  
  myBar = new BarChart(50, 200, 900, 500, lump1, lump2);
 
  header1 = XMLGetContent('t', "http://news.google.com/news?q=economy&output=rss");
  int tagpos = header1.indexOf("-");
  header1 = header1.substring(0, tagpos);
  
  bar1 = loadImage(XMLGetString("channel/item/media:thumbnail", "url", "http://feeds.bbci.co.uk/news/rss.xml"));
  bar2 = loadImage(XMLGetString("channel/item/media:thumbnail", "url", "http://feeds.bbci.co.uk/news/rss.xml"));
  
  lump1.clear();
  lump2.clear();
  /**************
  PIE CHART
  ***************/
  for(int i = 0; i < 10; i++)
  {
    String date = XMLGetString("news/news_entry/date", "data", "http://www.google.com/ig/api?news");
    float multi = 1;
    int dateTotal;
    if(matchAll(date, "hour") != null)
    {
      multi = 30;
    }
    if(date.charAt(1) == ' ')
    {
      dateTotal = (int)((Integer.parseInt(date.substring(0, 1))) * multi);
    }
    else
    {
      dateTotal = (int)((Integer.parseInt(date.substring(0, 2))) * multi);
    }
    lump1.add(dateTotal);
  }
  
  myPie1 = new PieChart(400, lump1, 250, 350);
  myPie1.setColour(25, 160, 25);
  
  headerPie = XMLGetContent('t', "http://news.google.com/news?q=debt&output=rss");
  int tagpos2 = headerPie.indexOf(" - ");
  headerPie = headerPie.substring(0, tagpos2);
  
  for(int i = 0; i < 12; i++)
  {
    String description = XMLGetContent('t', "http://news.google.com/news?ned=us&topic=b&output=rss");
    lump2.add(description.length());
  }
  myPie2 = new PieChart(300, lump2, 700, 500);
  myPie2.setColour(100, 50, 150);
  
  lump1.clear();
  lump2.clear();
  
  /**************
  3D LINE GRAPH
  ***************/
  for(int i = 0; i < 8; i++)
  {
    String description = XMLGetContent('t', "http://news.google.com/news?ned=us&topic=b&output=rss");
    lump1.add(PApplet.parseFloat(description.length()));
    lump2.add(XMLGetString("news/news_entry/num_related", "data", "http://www.google.com/ig/api?news"));
  }
  my3dLineGraph = new ThreeDeeLineGraph(100, 450, 900, 250, lump1, lump2);
  my3dLineGraph2 = new ThreeDeeLineGraph(100, 25, 900, 250, lump1, lump2);
  my3dLineGraph2.reversal();
  
  header3d = XMLGetContent('t', "http://news.google.com/news?q=stock&output=rss");
  int tagpos3 = header3d.indexOf(" - ");
  header3d = header3d.substring(0, tagpos3);
}

/*******************************
~~~~~~~~~~DRAW FUNCTION~~~~~~~~~
*******************************/
public void draw()
{
  background(25);
  
  if(slide == 0)
  {
    fill(255);
    textSize(150);
    textAlign(LEFT);
    text("The World in Data", 25, 150, 1000, 500);
  }
  //Draw the bar chart
  if(slide == 1)
  {
    fill(255);
    int sizey = PApplet.parseInt(20.0f * 70/header1.length());
    textSize(sizey);
    textAlign(CENTER);
    text(header1, width/2, 60);
    
    myBar.render();
    
    image(bar1, 600, 80, 160, 100);
    image(bar2, 800, 80, 160, 100);
  }
  //Draw the pie charts
  else if (slide == 2)
  {
    fill(255);
    int sizey = PApplet.parseInt(20.0f * 70/headerPie.length());
    textSize(sizey);
    textAlign(CENTER);
    text(headerPie, width/2, 60);
    
    myPie1.render();
    myPie2.render();
  }
  //Draw the 3d Line Graphs
  else if (slide == 3)
  {
    my3dLineGraph.render();
    my3dLineGraph2.render();
    
    stroke(255);
    noFill();
    beginShape();
    vertex(30, 25);
    vertex(30, 345);
    vertex(50, 350);
    vertex(10, 355);
    vertex(30, 360);
    vertex(30, 730);
    vertex(1000, 730);
    endShape();
    
    
    fill(255);
    int sizey = PApplet.parseInt(20.0f * 70/header3d.length());
    textSize(sizey);
    textAlign(CENTER);
    text(header3d, width/2, height/2);
  }
  
  //exit();
}

/*******************************
~~~~~~TAKES STRINGS FROM XML~~~~
*******************************/
public String XMLGetContent(char request, String feed)
{
  XMLElement xml;
  XMLElement[] kid;
  xml = new XMLElement(this, feed);
  String output = "DEFAULT";
  
  switch(request)
  {
    case 't':
      kid = xml.getChildren("channel/item/title");
      output = kid[PApplet.parseInt(random(0, kid.length))].getContent();
      break;
    case 's':
      kid = xml.getChildren("channel/item/source");
      output = kid[PApplet.parseInt(random(0, kid.length))].getContent();
      break;
    default:
      kid = xml.getChildren("channel");
      break;
  }
  return output;
}

/*******************************
~~~~TAKES SUBSTRINGS FROM XML~~~
*******************************/
public String XMLGetString(String request, String type, String feed)
{ 
  XMLElement xml;
  XMLElement[] kid;
  xml = new XMLElement(this, feed);
  String output = "DEFAULT";
  
  kid = xml.getChildren(request);
  output = kid[PApplet.parseInt(random(0, kid.length))].getString(type);
  
  return output;
}

/*******************************
~~~~~~~~~~~MOUSE INPUT~~~~~~~~~~
*******************************/
public void mouseClicked()
{
  if(mouseButton == LEFT)
  {
    if(slide < 3)
    {
      slide++;
    }
    else
    {
      slide = 0;  
    }
  }
  if(mouseButton == RIGHT)
  {
    
  }
}
class BarChart
{
  int x;
  int y;
  int maxWidth;
  int maxHeight;
  int barDistance;
  int[] colours;
  ArrayList data;
  ArrayList labels;
  
  BarChart(int xPos, int yPos, int inputWidth, int inputHeight, ArrayList inputData, ArrayList inputLabels)
  {
    x = xPos;
    y = yPos;
    maxWidth = inputWidth;
    maxHeight = inputHeight;
    colours = new int[25];
    loadColours();
    data = new ArrayList();
    labels = new ArrayList();
    for (int i = 0; i < inputData.size(); i++) 
    { 
      int inputDatum = ((Integer) inputData.get(i)) / 2;
      data.add(inputDatum);
      String grabLabel = (String) inputLabels.get(i);
      labels.add(grabLabel);
    }
    barDistance = 60;
  }
  
  public void render()
  {
    int j = 0;
    stroke(255);
    strokeWeight(5);
    line(x, y, x, y + barDistance * data.size());
    line(x, y - 3, x + maxWidth, y - 3);
    
    for(int i = 0; i < 10; i++)
    {
      textSize(10);
      fill(255);
      text(100 * i, x + 100 * i, y - 10);
    }
    
    textAlign(LEFT);
    fill(250);
    textSize(24);
    //text(source, x, y - 15);
    
    for(int i = 0; i < data.size(); i++)
    {
      int datum = (Integer) data.get(i);
      String grabLabel = (String) labels.get(i);
      
      noStroke();
      fill(colours[i]);
      if(datum > .75f * maxWidth + 25)
      {
        int breakpoint = PApplet.parseInt(.75f * maxWidth);
        int newDatum = (.1f * datum + breakpoint > maxWidth) ? PApplet.parseInt(.2f * maxWidth) : PApplet.parseInt(.1f * datum);
        
        beginShape();
        vertex(x, y + j);
        vertex(x + breakpoint - 10, y + j);
        vertex(x + breakpoint - 20, y + j + 25);
        vertex(x + breakpoint - 10, y + j + 50);
        vertex(x, y + j + 50);
        endShape();
        
        beginShape();
        vertex(x + breakpoint, y + j);
        vertex(x + breakpoint + newDatum, y + j);
        vertex(x + breakpoint + newDatum, y + j + 50);
        vertex(x + breakpoint, y + j + 50);
        vertex(x + breakpoint - 10, y + j + 25);
        endShape();
        
        textSize(14);
        fill(255);
        text(grabLabel, newDatum + breakpoint, y + j + 30);
      }
      else
      {
        rect(x, y + j, datum, 50);
        textSize(14);
        fill(255);
        text(grabLabel, (datum > 100) ? datum : datum + 60, y + j + 30);
      }
      
      
      
      j += barDistance;
    }
  }
  
  public void loadColours()
  {
    colours[0] = color(255, 0, 0);
    colours[1] = color(255, 255, 0);
    colours[2] = color(0, 255, 0);
    colours[3] = color(0, 255, 255);
    colours[4] = color(255, 0, 255);
    colours[5] = color(193, 39, 45);
    colours[6] = color(237, 28, 36);
    colours[7] = color(241, 90, 36);
    colours[8] = color(217, 224, 33);
    colours[9] = color(147, 39, 143);
  }
}
class PieChart
{
  float diameter;
  ArrayList angles,colors, data;
  float lastAngle;
  int x, y;
  int totalValues;
  
  PieChart(float inputDiameter, ArrayList inputAngles, int xPos, int yPos)
  {
    diameter = inputDiameter;
    angles = new ArrayList();
    colors = new ArrayList();
    data = new ArrayList();
    for(int i = 0; i < inputAngles.size(); i++)
    {
      int inputAngle = (Integer) inputAngles.get(i);
      totalValues += inputAngle;
      data.add(inputAngle);
    }
    
    int totalem = 0;
    for (int i = 0; i < inputAngles.size(); i++) 
    { 
      int inputAngle = (Integer) inputAngles.get(i);
      int angleCalc = PApplet.parseInt(((1.0f * inputAngle) / (1.0f * totalValues)) * 360.0f);
      if(i == inputAngles.size() - 1)
      {
        angleCalc = 360 - totalem;
      }
      angles.add(angleCalc);
      colors.add(color(random(0, 255), random(0, 255), random(0, 255)));
      totalem += angleCalc;
    }
    //angles.add(15);
    //colors.add(color(random(0, 255), random(0, 255), random(0, 255)));
    lastAngle = 0;
    x = xPos;
    y = yPos;
  }
  
  public void render()
  {
    stroke(255);
    strokeWeight(1);
    for (int i = 0; i < angles.size(); i++) 
    {
      int drawAngle = (Integer) angles.get(i);
      
      fill(255);
      textSize(14);
      float textX = cos(lastAngle + PI + radians(drawAngle/2)) * (diameter / 1.8f);
      float textY = sin(lastAngle + PI + radians(drawAngle/2)) * (diameter / 1.8f);
      int datum = (Integer) data.get(i);
      text(datum, x - textX, y - textY);
      //println(textX);
      
      
      int drawColor = (int)(Integer) colors.get(i);
      fill(drawColor);
      arc(x, y, diameter, diameter, lastAngle, lastAngle+radians(drawAngle));
      lastAngle += radians(drawAngle);
    }
    lastAngle = 0;
  }
  
  public void setDiameter(float newDiameter)
  {
    diameter = newDiameter;
  }
  
  public void setColour(int r, int g, int b)
  {
    if(r > 245)
    {
      r = 245;
    }
    else if(r < 10)
    {
      r = 10;
    }
    if(g > 245)
    {
      g = 245;
    }
    if (g < 10)
    {
      g = 10;
    }
    if (b > 245)
    {
      b = 245;
    }
    if (b < 10)
    {
      b = 10;
    }
    
    for (int i = 0; i < colors.size(); i++) 
    {
      colors.set(i, color(random(-10 + r, 10 + r), random(-10 + g, 10 + g), random(-10 + b, 10 + b)));
    }
  }
}
  
class ThreeDeeLineGraph
{
  boolean reversed;
  int x, y;
  int maxWidth, maxHeight;
  float topData;
  float pointDistance, rearPointDistance;
  ArrayList data, labels;
  int[] colours;
  
  ThreeDeeLineGraph(int xPos, int yPos, int inputWidth, int inputHeight, ArrayList inputData, ArrayList inputLabels)
  {
    x = xPos;
    y = yPos;
    maxWidth = inputWidth;
    maxHeight = inputHeight;
    
    colours = new int[25];
    loadColours();
    
    data = new ArrayList();
    labels = new ArrayList();
    topData = 0;
    for (int i = 0; i < inputData.size(); i++) 
    { 
      float inputDatum = (Float) inputData.get(i);
      data.add(inputDatum);
      if(inputDatum > topData)
      {
        topData = inputDatum;
      }
      String grabLabel = (String) inputLabels.get(i);
      labels.add(grabLabel);
    }
    
    pointDistance = maxWidth / data.size();
    rearPointDistance = maxWidth / data.size() / 1.2f;
    
    reversed = false;
  }
  
  public void render()
  {
    if(reversed == true)
    {
      fill(colours[2]);
      beginShape();
      vertex(x - 50, y);
      vertex(x - 50, y + maxHeight / 2);
      for(int i = 0; i < data.size(); i++)
      {
        float datum = (Float) data.get(i);
        vertex(x + i * rearPointDistance, y + PApplet.parseInt(datum / topData * maxHeight * 1.1f));
      }
      vertex(x + maxWidth, y);
      vertex(x - 50, y);
      endShape();
      
      fill(colours[2]);
      for(int i = 0; i < data.size(); i++)
      {
        float datum = (Float) data.get(i);
        beginShape();
        vertex(x + i * rearPointDistance, y + PApplet.parseInt(datum / topData * maxHeight * 1.1f));
        vertex(x + i * pointDistance, y + PApplet.parseInt(datum / topData * maxHeight));
        vertex(x + i * pointDistance, y + 25);
        endShape();
      }
      
      fill(colours[2]);
      strokeWeight(2);
      beginShape();
      vertex(x - 50, y);
      vertex(x - 50, y + maxHeight / 2);
      for(int i = 0; i < data.size(); i++)
      {
        float datum = (Float) data.get(i);
        vertex(x + i * pointDistance, y + PApplet.parseInt(datum / topData * maxHeight));
      }
      vertex(x + maxWidth, y);
      vertex(x - 50, y);
      endShape();
      
      for(int i = 0; i < labels.size(); i++)
      {
        float datum = (Float) data.get(i);
        
        strokeWeight(2);
        fill(255);
        String grabLabel = (String) labels.get(i);
        textSize(14);
        text(grabLabel, x + i * pointDistance, y + PApplet.parseInt(datum / topData * maxHeight * .8f));
      }
    }
    else
    {
      fill(colours[10]);
      strokeWeight(2);
      beginShape();
      vertex(x - 50, y + maxHeight);
      vertex(x - 50, y + maxHeight / 2);
      for(int i = 0; i < data.size(); i++)
      {
        float datum = (Float) data.get(i);
        vertex(x + i * rearPointDistance, y + maxHeight - PApplet.parseInt(datum / topData * maxHeight * 1.1f));
      }
      vertex(x + maxWidth, y + maxHeight);
      vertex(x - 50, y + maxHeight);
      endShape();
      
      fill(colours[10]);
      strokeWeight(2);
      for(int i = 0; i < data.size(); i++)
      {
        float datum = (Float) data.get(i);
        beginShape();
        vertex(x + i * rearPointDistance, y + maxHeight - PApplet.parseInt(datum / topData * maxHeight * 1.1f));
        vertex(x + i * pointDistance, y + maxHeight - PApplet.parseInt(datum / topData * maxHeight));
        vertex(x + i * pointDistance, y + maxHeight - 25);
        endShape();
      }
      
      fill(colours[10]);
      strokeWeight(2);
      beginShape();
      vertex(x - 50, y + maxHeight);
      vertex(x - 50, y + maxHeight / 2);
      for(int i = 0; i < data.size(); i++)
      {
        float datum = (Float) data.get(i);
        vertex(x + i * pointDistance, y + maxHeight - PApplet.parseInt(datum / topData * maxHeight));
      }
      vertex(x + maxWidth, y + maxHeight);
      vertex(x - 50, y + maxHeight);
      endShape();
      
      for(int i = 0; i < labels.size(); i++)
      {
        float datum = (Float) data.get(i);
        
        strokeWeight(2);
        fill(255);
        String grabLabel = (String) labels.get(i);
        textSize(14);
        text(grabLabel, x + i * pointDistance, y + maxHeight - PApplet.parseInt(datum / topData * maxHeight * .8f));
      }
    }
  }
  
  public void reversal()
  {
    if(reversed)
    {
      reversed = false;
    }
    else
    {
      reversed = true;
    }
  }
    
  public void loadColours()
  {
    colours[0] = color(255, 0, 0);
    colours[1] = color(255, 255, 0);
    colours[2] = color(0, 255, 0); //Bright green
    colours[3] = color(0, 255, 255);
    colours[4] = color(255, 0, 255);
    colours[5] = color(193, 39, 45);
    colours[6] = color(237, 28, 36);
    colours[7] = color(241, 90, 36);
    colours[8] = color(217, 224, 33);
    colours[9] = color(147, 39, 143);
    colours[10] = color(255, 105, 180); //Hot pink
  }
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "Final380DataJunker" });
  }
}
